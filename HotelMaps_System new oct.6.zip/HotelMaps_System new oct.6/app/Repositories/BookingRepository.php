<?php
// app/Repositories/BookingRepository.php

namespace App\Repositories;

use App\Database\Database;
use PDO;

class BookingRepository {
    private ?PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getBookingsByUser(?string $userId, ?string $sessionId): array {
        if (!$this->db) {
            return $_SESSION['local_bookings'] ?? [];
        }

        try {
            if ($userId && strpos($userId, 'guest_') !== 0) {
                $stmt = $this->db->prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC");
                $stmt->execute([$userId]);
            } else {
                $stmt = $this->db->prepare("SELECT * FROM bookings WHERE session_id = ? ORDER BY created_at DESC");
                $stmt->execute([$sessionId]);
            }
            $rows = $stmt->fetchAll();
            $bookings = [];
            foreach ($rows as $row) {
                $bookings[] = [
                    'id'          => $row['booking_id'],
                    'stayId'      => $row['hotel_id'],
                    'stayTitle'   => $row['hotel_title'],
                    'roomId'      => $row['room_id'] ?? '',
                    'roomName'    => $row['room_name'] ?? 'Deluxe Room',
                    'roomNumber'  => $row['room_number'] ?? '',
                    'guestName'   => $row['guest_name'],
                    'guestPhone'  => $row['guest_phone'],
                    'checkInTime' => $row['check_in_time'],
                    'stayType'    => $row['stay_type'],
                    'nights'      => (int)($row['nights'] ?? 1),
                    'amount'      => (float)$row['amount'],
                    'status'      => $row['status'] ?? 'CONFIRMED',
                    'createdAt'   => $row['created_at']
                ];
            }
            return $bookings;
        } catch (\Exception $e) {
            return $_SESSION['local_bookings'] ?? [];
        }
    }

    public function createBooking(array $data): string {
        $bookingId = 'BK-' . strtoupper(substr(uniqid(), 7, 6));

        if ($this->db) {
            try {
                $stmt = $this->db->prepare("
                    INSERT INTO bookings 
                    (booking_id, hotel_id, session_id, user_id, room_id, hotel_title, room_name, room_number, guest_name, guest_email, guest_phone, stay_type, check_in_time, nights, amount, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED')
                ");
                $stmt->execute([
                    $bookingId,
                    $data['hotel_id'] ?? $data['stay_id'],
                    $data['session_id'],
                    $data['user_id'],
                    $data['room_id'] ?? null,
                    $data['hotel_title'] ?? 'Metro Manila Stay',
                    $data['room_name'] ?? 'Deluxe Room',
                    $data['room_number'] ?? '',
                    $data['guest_name'] ?? 'Guest Traveler',
                    $data['guest_email'] ?? null,
                    $data['guest_phone'] ?? '',
                    $data['stay_type'] ?? '3-Hour Wash Rate',
                    $data['check_in_time'] ?? date('Y-m-d H:i:s'),
                    $data['nights'] ?? 1,
                    $data['amount'] ?? 0
                ]);
            } catch (\Exception $e) {
                // If db fails, save in session
                $this->saveToSession($bookingId, $data);
            }
        } else {
            $this->saveToSession($bookingId, $data);
        }

        return $bookingId;
    }

    private function saveToSession(string $bookingId, array $data): void {
        if (!isset($_SESSION['local_bookings'])) {
            $_SESSION['local_bookings'] = [];
        }
        $_SESSION['local_bookings'][] = [
            'id'          => $bookingId,
            'stayId'      => $data['hotel_id'] ?? $data['stay_id'],
            'stayTitle'   => $data['hotel_title'] ?? 'Metro Manila Stay',
            'roomId'      => $data['room_id'] ?? '',
            'roomName'    => $data['room_name'] ?? 'Deluxe Room',
            'roomNumber'  => $data['room_number'] ?? '',
            'guestName'   => $data['guest_name'] ?? 'Guest Traveler',
            'guestPhone'  => $data['guest_phone'] ?? '',
            'checkInTime' => $data['check_in_time'] ?? date('Y-m-d H:i:s'),
            'stayType'    => $data['stay_type'] ?? '3-Hour Wash Rate',
            'nights'      => (int)($data['nights'] ?? 1),
            'amount'      => (float)($data['amount'] ?? 0),
            'status'      => 'CONFIRMED',
            'createdAt'   => date('Y-m-d H:i:s')
        ];
    }

    public function cancelBooking(string $bookingId): bool {
        if ($this->db) {
            try {
                $stmt = $this->db->prepare("DELETE FROM bookings WHERE booking_id = ?");
                return $stmt->execute([$bookingId]);
            } catch (\Exception $e) {}
        }
        if (isset($_SESSION['local_bookings'])) {
            $_SESSION['local_bookings'] = array_values(array_filter($_SESSION['local_bookings'], fn($b) => $b['id'] !== $bookingId));
        }
        return true;
    }
}
