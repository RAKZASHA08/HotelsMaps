<?php
// app/bootstrap.php - Autoloader and Application Bootstrapper

spl_autoload_register(function (string $class): void {
    $prefix  = 'App\\\\';
    $baseDir = __DIR__ . '/';

    if (strncmp($prefix, $class, strlen($prefix)) !== 0) {
        return;
    }

    $relativeClass = substr($class, strlen($prefix));
    $file          = $baseDir . str_replace('\\\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

// Make DB connection available via $pdo global
require_once __DIR__ . '/../db.php';