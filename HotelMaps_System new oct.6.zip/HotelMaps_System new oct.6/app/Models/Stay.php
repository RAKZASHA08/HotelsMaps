<?php
// app/Models/Stay.php

namespace App\Models;

class Stay {
    public string $id;
    public string $title;
    public string $branchName;
    public string $brand;
    public string $category;
    public string $categoryDisplay;
    public string $address;
    public string $city;
    public float $rating;
    public int $ratingCount;
    public int $viewsCount;
    public int $totalBooked;
    public float $price;
    public float $priceFrom;
    public string $durationLabel;
    public float $lat;
    public float $lng;
    public string $image;
    public array $tags;
    public string $statusText;
    public string $statusBadgeClass;
    public bool $instant;
    public string $nearestTerminal;
    public string $transitType;
    public string $walkTime;
    public array $hourlyRates;
    public array $rooms;

    public function __construct(array $data) {
        $this->id               = $data['id'] ?? '';
        $this->title            = $data['title'] ?? '';
        $this->branchName       = $data['branch_name'] ?? 'Main Branch';
        $this->brand            = $data['brand'] ?? 'Motel / Hotel';
        $this->category         = $data['category'] ?? 'motel';
        $this->categoryDisplay  = $data['categoryDisplay'] ?? $data['category_display'] ?? 'Motel / Drive-in';
        $this->address          = $data['address'] ?? '';
        $this->city             = $data['city'] ?? 'Metro Manila';
        $this->rating           = (float)($data['rating'] ?? 4.5);
        $this->ratingCount      = (int)($data['ratingCount'] ?? $data['rating_count'] ?? 0);
        $this->viewsCount       = (int)($data['viewsCount'] ?? $data['views_count'] ?? 0);
        $this->totalBooked      = (int)($data['totalBooked'] ?? $data['total_booked'] ?? 0);
        $this->price            = (float)($data['price'] ?? $data['price_from'] ?? 450);
        $this->priceFrom        = (float)($data['price_from'] ?? $this->price);
        $this->durationLabel    = $data['durationLabel'] ?? $data['duration_label'] ?? '3-Hour Wash Rate';
        $this->lat              = (float)($data['lat'] ?? 14.5995);
        $this->lng              = (float)($data['lng'] ?? 120.9842);
        $this->image            = $data['image'] ?? '';
        $this->tags             = $data['tags'] ?? ['Walk-in Ready', 'Near Transit'];
        $this->statusText       = $data['statusText'] ?? $data['status_text'] ?? 'Rooms Available Now';
        $this->statusBadgeClass = $data['statusBadgeClass'] ?? $data['status_badge'] ?? 'status-walkin';
        $this->instant          = (bool)($data['instant'] ?? true);
        $this->nearestTerminal  = $data['nearest_terminal'] ?? 'Nearest Station / Terminal';
        $this->transitType      = $data['transit_type'] ?? 'MRT / Busway';
        $this->walkTime         = $data['walk_time'] ?? '3 mins walk';
        $this->hourlyRates      = $data['hourly_rates'] ?? [
            '2hr'  => 360,
            '3hr'  => 450,
            '6hr'  => 750,
            '12hr' => 1100,
            '24hr' => 1600
        ];
        $this->rooms            = $data['rooms'] ?? [];
    }

    public function toArray(): array {
        return [
            'id'                 => $this->id,
            'title'              => $this->title,
            'branch_name'        => $this->branchName,
            'brand'              => $this->brand,
            'category'           => $this->category,
            'categoryDisplay'    => $this->categoryDisplay,
            'address'            => $this->address,
            'city'               => $this->city,
            'rating'             => $this->rating,
            'ratingCount'        => $this->ratingCount,
            'viewsCount'         => $this->viewsCount,
            'totalBooked'        => $this->totalBooked,
            'price'              => $this->price,
            'price_from'         => $this->priceFrom,
            'durationLabel'      => $this->durationLabel,
            'rateTypeLabel'      => ($this->category === 'motel' || $this->category === 'sogo') ? 'HOURLY WALK-IN RATE' : 'NIGHTLY RATE',
            'lat'                => $this->lat,
            'lng'                => $this->lng,
            'image'              => $this->image,
            'tags'               => $this->tags,
            'statusText'         => $this->statusText,
            'statusBadgeClass'   => $this->statusBadgeClass,
            'instant'            => $this->instant,
            'nearest_terminal'   => $this->nearestTerminal,
            'transit_type'       => $this->transitType,
            'walk_time'          => $this->walkTime,
            'hourly_rates'       => $this->hourlyRates,
            'rooms'              => $this->rooms
        ];
    }
}
