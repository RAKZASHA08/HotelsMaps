<?php
require __DIR__ . '/app/Views/index.view.php';