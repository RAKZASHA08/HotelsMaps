<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../app/bootstrap.php';

$isLoggedIn = !empty($_SESSION['user_id']) && (($_SESSION['role'] ?? '') !== 'guest') && (strpos((string)$_SESSION['user_id'], 'guest_') !== 0);
$userEmail = $_SESSION['user_email'] ?? 'guest@comfortvue.ph';

if (!$isLoggedIn) {
    header("Location: auth.php");
    exit;
}

// Auto-create saved_locations table if it doesn't exist
if ($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `saved_locations` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` VARCHAR(64) NOT NULL,
        `hotel_id` VARCHAR(64) NOT NULL,
        `saved_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY user_hotel (user_id, hotel_id)
    )");
}

$savedDestinations = [];
if ($pdo) {
    // Join with hotels table to get details
    $stmt = $pdo->prepare("
        SELECT s.saved_at, h.* 
        FROM saved_locations s
        JOIN hotels h ON s.hotel_id = h.id
        WHERE s.user_id = ?
        ORDER BY s.saved_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $savedDestinations = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Destination Library - StayFinder PH</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body style="background: var(--cream);">
  
  <header class="app-header bg-white border-bottom shadow-sm sticky-top" style="border-color: var(--border)!important;">
    <div class="container px-4 d-flex align-items-center justify-content-between py-3">
      <a href="dashboard.php" class="d-flex align-items-center gap-2 text-decoration-none">
        <div class="brand-logo-badge" style="width:36px; height:36px; border-radius:10px;"><i class="bi bi-compass"></i></div>
        <span class="fs-5 fw-bold text-mocha tracking-tight">StayFinder PH</span>
      </a>
      <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4 fw-bold">Back to Dashboard</a>
    </div>
  </header>

  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-extrabold text-mocha mb-0"><i class="bi bi-pin-map-fill text-info me-2"></i>Destination Library</h2>
      <span class="badge bg-info rounded-pill px-3 py-2 fs-6"><?= count($savedDestinations) ?> Saved</span>
    </div>

    <?php if (empty($savedDestinations)): ?>
      <div class="text-center py-5">
        <i class="bi bi-heartbreak text-muted" style="font-size: 4rem;"></i>
        <h4 class="mt-3 text-mocha">Your library is empty.</h4>
        <p class="text-secondary">Save your favorite destinations from the map to view them here.</p>
        <a href="home.php" class="btn btn-primary rounded-pill mt-2 px-4">Explore Map</a>
      </div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($savedDestinations as $dest): ?>
          <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-4 overflow-hidden h-100" style="background: var(--bg-card); transition: transform 0.2s;">
              <img src="<?= htmlspecialchars($dest['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($dest['title']) ?>" style="height: 180px; object-fit: cover;">
              <div class="card-body">
                <h5 class="fw-bold text-mocha mb-1"><?= htmlspecialchars($dest['title']) ?></h5>
                <p class="small text-secondary mb-3"><i class="bi bi-geo-alt-fill text-terracotta me-1"></i><?= htmlspecialchars($dest['city']) ?></p>
                <div class="d-flex justify-content-between align-items-center">
                  <span class="fw-bold text-sage">₱<?= number_format($dest['price_from']) ?></span>
                  <a href="home.php?locate=<?= urlencode($dest['id']) ?>" class="btn btn-sm btn-primary rounded-pill px-3">View Details</a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

</body>
</html>
