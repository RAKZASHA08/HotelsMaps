<?php
// add_new_branches.php
require 'db.php';

try {
    $hotels = [
        // CEBU
        ['hotel-crimson-mactan', 'Crimson Resort & Spa', 'Chroma Hospitality', 'resort', 'Luxury Beach Resort', 'Seascapes Resort Town, Mactan Island, Cebu', 'Cebu & Mactan', 4.85, 9500.00, 10.3065, 124.0150, 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=800&q=80', 'Private Villa, Infinity Pool, Aum Spa', 'Mactan Seaside Branch'],
        ['hotel-radisson-cebu', 'Radisson Blu Cebu', 'Radisson Hotels', 'hotel', '5-Star City Hotel', 'Serging Osmena Boulevard, Corner Juan Luna Avenue, Cebu City', 'Cebu City', 4.88, 6500.00, 10.3129, 123.9184, 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80', 'Direct SM City Access, Massive Pool, Luxury Buffet', 'Cebu City Center Branch'],
        
        // DAVAO
        ['hotel-dusit-davao', 'Dusit Thani Residence Davao', 'Dusit International', 'hotel', 'Luxury City Hotel', 'Stella Hizon Reyes Drive, Bo. Pampanga, Davao City', 'Davao City', 4.90, 7200.00, 7.1085, 125.6450, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=800&q=80', 'Gulf View, Benjarong Restaurant, Premium Spa', 'Davao Gulf Branch'],
        ['hotel-pearl-farm', 'Pearl Farm Beach Resort', 'Pearl Farm', 'resort', 'Exclusive Island Resort', 'Kaputian, Island Garden City of Samal, Davao', 'Samal Island (Davao)', 4.92, 12500.00, 7.0094, 125.7264, 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80', 'Overwater Villas, White Sand Beach, Marina', 'Samal Island Resort'],
        
        // BAGUIO
        ['hotel-manor-cjh', 'The Manor at Camp John Hay', 'Camp John Hay', 'hotel', 'Premium Mountain Resort', 'Loakan Road, Camp John Hay, Baguio City', 'Baguio City', 4.85, 5800.00, 16.3982, 120.6125, 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80', 'Pine Tree Views, Fireplace, Golf Course Access', 'Camp John Hay Branch'],
        
        // PALAWAN (NEW)
        ['resort-elnido-lagen', 'El Nido Resorts Lagen Island', 'Ten Knots', 'resort', 'Eco-Luxury Island Resort', 'Lagen Island, El Nido, Palawan', 'El Nido Palawan', 4.95, 24000.00, 11.0850, 119.3900, 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80', 'Overwater Cottages, Private Lagoon, Eco Tours', 'Lagen Island Cove'],
        ['resort-princesa-garden', 'Princesa Garden Island Resort', 'Princesa Garden', 'resort', 'Luxury Sandbar Resort', 'Caniguiran, Puerto Princesa, Palawan', 'Puerto Princesa', 4.82, 8500.00, 9.7360, 118.7562, 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=800&q=80', 'Sandbar Access, Huge Pool Network, Floating Villas', 'Puerto Princesa Branch'],
        
        // BORACAY (NEW)
        ['resort-shang-boracay', 'Shangri-La Boracay', 'Shangri-La Hotels & Resorts', 'resort', 'Ultra Luxury Beach Resort', 'Barangay Yapak, Boracay Island, Malay, Aklan', 'Boracay Island', 4.97, 28000.00, 11.9936, 121.9142, 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=800&q=80', 'Private Banyugan Beach, Clifftop Villas, CHI Spa', 'Yapak Premium Branch'],
        ['resort-discovery-boracay', 'Discovery Shores Boracay', 'Discovery Hospitality', 'resort', 'Luxury Beachfront Resort', 'Station 1, Balabag, Boracay Island', 'Boracay Island', 4.93, 19500.00, 11.9680, 121.9180, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=800&q=80', 'Station 1 White Beach, Signature Service, Indigo Restaurant', 'Station 1 Branch'],
        
        // METRO MANILA AIRBNBS
        ['airbnb-gramercy', 'Gramercy Skyline Studio', 'Gramercy Residences', 'airbnb', 'High-Rise Condo Staycation', 'Kalayaan Avenue, Century City, Makati CBD', 'Makati CBD', 4.78, 3500.00, 14.5658, 121.0287, 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80', '71st Floor Bar, Infinity Pool, Century Mall Access', 'Century City Hub'],
        ['airbnb-venice', 'The Venice Romantic Suite', 'Venice Luxury Residences', 'airbnb', 'European-Themed Staycation', 'Venezia Drive, McKinley Hill, Taguig', 'BGC Taguig', 4.70, 4200.00, 14.5332, 121.0543, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80', 'Grand Canal View, Gondola Rides, Fast Wi-Fi', 'McKinley Hill Branch'],
        ['airbnb-azure', 'Azure Urban Beach Resort Stay', 'Azure Residences', 'airbnb', 'Man-Made Beach Staycation', 'SLEX West Service Road, Bicutan, Parañaque', 'Entertainment City', 4.65, 2800.00, 14.4881, 121.0435, 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=800&q=80', 'Wave Pool, White Sand Beach, Paris Beach Club', 'Bicutan Branch']
    ];

    $stmtHotel = $pdo->prepare("INSERT IGNORE INTO hotels (id, title, brand, category, category_display, address, city, rating, price_from, lat, lng, image, tags, branch_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmtRoom = $pdo->prepare("INSERT IGNORE INTO hotel_rooms (id, hotel_id, room_number, room_name, room_type, price, capacity, bed_type, size_sqm, amenities, status, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Available', ?)");

    $images = [
        'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1595576508898-0ad5c879a061?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=600&q=80'
    ];

    foreach ($hotels as $h) {
        $stmtHotel->execute($h);

        // Add 3 rooms for each new hotel
        for ($i = 1; $i <= 3; $i++) {
            $roomId = 'rm-' . $h[0] . '-' . $i;
            $rNum = 'Room ' . $i . '0' . rand(1, 9);
            $rName = ($i == 1) ? 'Standard Unit' : (($i == 2) ? 'Deluxe Suite' : 'Premium / Executive Suite');
            $rType = ($i == 1) ? 'Standard' : (($i == 2) ? 'Deluxe' : 'Premium');
            $price = $h[8] * (1 + ($i * 0.3)); // increment price
            $cap = '2 Adults';
            $bed = ($i == 1) ? '1 Queen Bed' : '1 King Bed';
            $sqm = 30 + ($i * 15);
            $amenities = 'Fast Wi-Fi, Smart TV, Air Conditioning, Hot & Cold Shower, Scenic Views';
            $img = $images[array_rand($images)];

            $stmtRoom->execute([$roomId, $h[0], $rNum, $rName, $rType, $price, $cap, $bed, $sqm, $amenities, $img]);
        }
    }

    echo "New regions and hotel branches seeded successfully!";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
