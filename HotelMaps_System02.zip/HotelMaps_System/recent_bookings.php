<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

$isLoggedIn = !empty($_SESSION['user_id']) && (($_SESSION['role'] ?? '') !== 'guest') && (strpos((string)$_SESSION['user_id'], 'guest_') !== 0);
$userName = $_SESSION['user_name'] ?? 'Guest Traveler';
$userEmail = $_SESSION['user_email'] ?? 'guest@comfortvue.ph';

if (!$isLoggedIn) {
    header("Location: auth.php");
    exit;
}

$bookings = [];
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Recent Bookings - StayFinder PH</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body style="background: var(--cream);">
  
  <header class="app-header bg-white border-bottom shadow-sm sticky-top" style="border-color: var(--border)!important;">
    <div class="container px-4 d-flex align-items-center justify-content-between py-3">
      <a href="dashboard.php" class="d-flex align-items-center gap-2 text-decoration-none">
        <div class="brand-logo-badge" style="width:36px; height:36px; border-radius:10px;"><i class="bi bi-compass"></i></div>
        <span class="fs-5 fw-bold text-mocha tracking-tight">StayFinder PH</span>
      </a>
      <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4 fw-bold">Back to Dashboard</a>
    </div>
  </header>

  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-extrabold text-mocha mb-0"><i class="bi bi-journal-check text-sage me-2"></i>Recent Bookings Log</h2>
      <span class="badge bg-sage rounded-pill px-3 py-2 fs-6"><?= count($bookings) ?> Total</span>
    </div>

    <?php if (empty($bookings)): ?>
      <div class="text-center py-5">
        <i class="bi bi-journal-x text-muted" style="font-size: 4rem;"></i>
        <h4 class="mt-3 text-mocha">No recent bookings found.</h4>
        <p class="text-secondary">Start exploring the map to book your first stay!</p>
        <a href="home.php" class="btn btn-primary rounded-pill mt-2 px-4">Explore Map</a>
      </div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($bookings as $b): ?>
          <div class="col-12 col-md-6">
            <div class="card shadow-sm border-0 rounded-4" style="background: var(--bg-card);">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                  <h5 class="card-title fw-bold text-mocha mb-0"><?= htmlspecialchars($b['hotel_title']) ?></h5>
                  <span class="badge <?= $b['status'] === 'CONFIRMED' ? 'bg-success' : 'bg-warning text-dark' ?> rounded-pill">
                    <?= htmlspecialchars($b['status']) ?>
                  </span>
                </div>
                <p class="mb-1 small text-secondary"><i class="bi bi-door-closed me-1"></i><?= htmlspecialchars($b['room_name']) ?> (Room <?= htmlspecialchars($b['room_number']) ?>)</p>
                <p class="mb-1 small text-secondary"><i class="bi bi-calendar-check me-1"></i>Check-in: <?= date('M d, Y h:i A', strtotime($b['check_in_time'])) ?></p>
                <p class="mb-3 small text-secondary"><i class="bi bi-clock-history me-1"></i><?= htmlspecialchars($b['nights']) ?> Night(s) / <?= htmlspecialchars($b['stay_type']) ?></p>
                <div class="d-flex justify-content-between align-items-center pt-3 border-top" style="border-color: var(--border)!important;">
                  <span class="fw-bold text-terracotta">₱<?= number_format($b['amount'], 2) ?></span>
                  <a href="home.php?locate=<?= urlencode($b['hotel_id']) ?>" class="btn btn-sm btn-outline-secondary rounded-pill">View Property</a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

</body>
</html>
