<?php
// Privacy & Security: Ensure session cookies are secure and protected
// Session already started by AuthMiddleware (via controller)
// DB connection injected by controller via app/Config/Database
$isLoggedIn = !empty($_SESSION['user_id']) && (($_SESSION['role'] ?? '') !== 'guest') && (strpos((string)$_SESSION['user_id'], 'guest_') !== 0);
$userName = $_SESSION['user_name'] ?? 'Guest Traveler';
$userEmail = $_SESSION['user_email'] ?? 'guest@comfortvue.ph';
$userRole = $_SESSION['role'] ?? 'guest';
$isAdmin = ($userRole === 'admin') || ($userEmail === 'admin@comfortvue.ph');
$isVerified = false;
$userBookingsCount = 0;

if ($isLoggedIn && $pdo && !empty($userEmail)) {
    try {
        $stmt = $pdo->prepare("SELECT is_verified, role FROM users WHERE email = ?");
        $stmt->execute([$userEmail]);
        $uRow = $stmt->fetch();
        if ($uRow) {
            $isVerified = (bool)($uRow['is_verified'] == 1);
            if ($uRow['role'] === 'admin') $isAdmin = true;
        }
    } catch (\Exception $e) {}
} else {
    $isVerified = !empty($_SESSION['is_verified']);
}

if ($isLoggedIn && $pdo && !empty($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userBookingsCount = $stmt->fetchColumn();
    } catch (\Exception $e) {}
}

// Fetch top trending hotels from db or mock them
$trendingHotels = [];
if ($pdo) {
    try {
        $stmt = $pdo->query("SELECT id, title, city, price_from, image, category_display FROM hotels ORDER BY rating DESC, views_count DESC LIMIT 6");
        $trendingHotels = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Exception $e) {}
}

if (empty($trendingHotels)) {
    $inventoryFile = dirname(__DIR__, 2) . '/data/stays_inventory.json';
    if (file_exists($inventoryFile)) {
        $raw = json_decode(file_get_contents($inventoryFile), true) ?: [];
        $trendingHotels = array_slice($raw, 0, 6);
    }
}

if ($userBookingsCount === 0 && !empty($_SESSION['mock_bookings'])) {
    $userBookingsCount = count($_SESSION['mock_bookings']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - ComfortVue PH</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body { background: var(--cream); overflow-x: hidden; }
    .dashboard-banner {
      background: linear-gradient(135deg, rgba(200,113,74,0.9), rgba(212,133,42,0.9)), url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1920&q=80') center/cover;
      color: white;
      border-radius: var(--r-xl);
      padding: 4rem 3rem;
      margin-bottom: 3rem;
      box-shadow: var(--shadow-md);
    }
    .trend-card {
      border: 1px solid var(--border);
      border-radius: var(--r-md);
      overflow: hidden;
      background: var(--bg-card);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      height: 100%;
    }
    .trend-card:hover {
      transform: translateY(-5px);
      box-shadow: var(--shadow-md);
    }
    .trend-card img {
      height: 200px;
      object-fit: cover;
      width: 100%;
    }
    .section-title {
      color: var(--mocha);
      font-weight: 800;
      margin-bottom: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .sidebar-menu {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: var(--r-md);
      padding: 1.5rem;
      height: calc(100vh - 120px);
      position: sticky;
      top: 100px;
    }
    .nav-link-custom {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 0.8rem 1rem;
      color: var(--text-primary);
      border-radius: var(--r-sm);
      text-decoration: none;
      font-weight: 600;
      margin-bottom: 0.5rem;
      transition: all 0.2s ease;
    }
    .nav-link-custom:hover, .nav-link-custom.active {
      background: rgba(200,113,74,0.1);
      color: var(--terracotta);
    }
    .dropdown-sidebar .btn {
      width: 100%;
      text-align: left;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.8rem 1rem;
      font-weight: 600;
      color: var(--text-primary);
      background: var(--cream-deep);
      border: 1px solid var(--border);
      margin-bottom: 0.5rem;
    }
  </style>
</head>
<body>

  <!-- Top Navigation Header -->
  <header class="app-header">
    <div class="container-fluid px-3 px-md-4 d-flex flex-wrap align-items-center justify-content-between gap-3">
      <a href="index.php" class="d-flex align-items-center gap-3 text-decoration-none">
        <div class="brand-logo-badge"><i class="bi bi-compass"></i></div>
        <div>
          <div class="d-flex align-items-center gap-2">
            <span class="fs-5 fw-bold tracking-tight" style="color: var(--mocha);">StayFinder PH</span>
            <span class="badge" style="background: rgba(200,113,74,0.12); color: var(--terracotta); border: 1px solid rgba(200,113,74,0.3); font-size: 0.68rem;">
              <i class="bi bi-patch-check-fill me-1"></i>Metro Manila
            </span>
          </div>
          <div style="font-size: 0.72rem; color: var(--text-muted);">Motels • Condo Staycations • Short-Term Rentals</div>
        </div>
      </a>

      <!-- Navigation & Action Controls -->
      <div class="d-flex align-items-center flex-wrap gap-2">
        <a href="dashboard.php" class="btn-nav-pill active text-decoration-none"><i class="bi bi-grid-fill"></i> Dashboard</a>
        <a href="home.php" class="btn-nav-pill text-decoration-none"><i class="bi bi-map"></i> Map</a>
        <a href="home.php?view=bookings" class="btn-nav-pill text-decoration-none">
          <i class="bi bi-journal-check"></i> My Bookings
          <span class="badge rounded-pill ms-1" style="background:var(--sage); font-size: 0.65rem;"><?= $userBookingsCount ?> Active</span>
        </a>

        <!-- Account Verification Badge / Action Button -->
        <?php if ($isVerified): ?>
          <span class="badge bg-success bg-opacity-20 text-success border border-success border-opacity-30 px-3 py-2 rounded-pill d-inline-flex align-items-center gap-1" style="font-size:0.75rem;">
            <i class="bi bi-patch-check-fill text-success"></i> Account Verified
          </span>
        <?php else: ?>
          <a href="home.php?action=verify" class="btn btn-sm btn-outline-warning rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-1 shadow-sm" title="Verify your actual account">
            <i class="bi bi-shield-exclamation text-warning"></i> Verify Account
          </a>
        <?php endif; ?>

        <!-- User Dropdown Menu -->
        <div class="dropdown">
          <button class="btn-nav-pill dropdown-toggle" type="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle text-info"></i> <?= htmlspecialchars($userName) ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end shadow border border-secondary border-opacity-50">
            <li>
              <div class="px-3 py-2">
                <span class="fw-bold text-white d-block"><?= htmlspecialchars($userName) ?></span>
                <span class="small text-secondary d-block"><?= htmlspecialchars($userEmail) ?></span>
                <div class="mt-2">
                  <?php if ($isVerified): ?>
                    <span class="badge bg-success" style="font-size:0.65rem;">
                      <i class="bi bi-patch-check-fill me-1"></i>Verified Traveler
                    </span>
                  <?php else: ?>
                    <span class="badge bg-warning text-dark" style="font-size:0.65rem;">
                      <i class="bi bi-exclamation-triangle me-1"></i>Unverified Account
                    </span>
                  <?php endif; ?>
                </div>
              </div>
            </li>
            <li><hr class="dropdown-divider border-secondary border-opacity-25"></li>
            <?php if (!$isVerified): ?>
              <li>
                <a class="dropdown-item text-warning" href="home.php?action=verify">
                  <i class="bi bi-shield-check me-2"></i>Verify Account with 6-Digit PIN
                </a>
              </li>
            <?php endif; ?>
            <li>
              <a class="dropdown-item text-light" href="profile.php">
                <i class="bi bi-person-gear me-2"></i>Account &amp; Profile Settings
              </a>
            </li>
            <li>
              <a class="dropdown-item text-light" href="home.php?view=bookings">
                <i class="bi bi-journal-text me-2"></i>View My Reservations (<?= $userBookingsCount ?>)
              </a>
            </li>
            <?php if ($userRole === 'guest'): ?>
              <li><hr class="dropdown-divider border-secondary border-opacity-25"></li>
              <li><a class="dropdown-item text-info" href="auth.php?action=register"><i class="bi bi-person-plus me-2"></i>Create Real Account</a></li>
            <?php endif; ?>
            <?php if ($isAdmin): ?>
              <li><hr class="dropdown-divider border-secondary border-opacity-25"></li>
              <li><a class="dropdown-item text-warning" href="admin.php"><i class="bi bi-shield-lock me-2"></i>Admin Console</a></li>
            <?php endif; ?>
            <li><hr class="dropdown-divider border-secondary border-opacity-25"></li>
            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Sign Out</a></li>
          </ul>
        </div>
      </div>
    </div>
  </header>

  <div class="container-fluid px-4 py-4 dashboard-content">
    <div class="row g-4">
      
      <!-- Sidebar / Dropdown Navigation Menu -->
      <div class="col-12 col-lg-3 col-xl-2">
        <div class="sidebar-menu shadow-sm">
          <h6 class="text-uppercase text-muted fw-bold small mb-3 tracking-tight">Navigation Menu</h6>
          
          <a href="dashboard.php" class="nav-link-custom active"><i class="bi bi-house-door-fill"></i> Dashboard Home</a>
          
          <div class="dropdown-sidebar mt-2">
            <button class="btn" type="button" data-bs-toggle="collapse" data-bs-target="#categoriesMenu">
              <span><i class="bi bi-tags-fill text-terracotta me-2"></i> Categories</span>
              <i class="bi bi-chevron-down"></i>
            </button>
            <div class="collapse" id="categoriesMenu">
              <div class="ps-4 pe-2 pb-2">
                <a href="home.php?category=hotel" class="d-block py-1 text-decoration-none text-secondary small fw-bold hover-text-terracotta"><i class="bi bi-building me-2"></i>Luxury Hotels</a>
                <a href="home.php?category=resort" class="d-block py-1 text-decoration-none text-secondary small fw-bold hover-text-terracotta"><i class="bi bi-tree me-2"></i>Beach Resorts</a>
                <a href="home.php?category=heritage" class="d-block py-1 text-decoration-none text-secondary small fw-bold hover-text-terracotta"><i class="bi bi-bank me-2"></i>Heritage Stays</a>
              </div>
            </div>
          </div>

          <a href="recent_bookings.php" class="nav-link-custom"><i class="bi bi-journal-check text-sage"></i> Recent Bookings</a>
          <a href="destination_list.php" class="nav-link-custom"><i class="bi bi-pin-map-fill text-info"></i> Destination List</a>
          <a href="profile.php" class="nav-link-custom"><i class="bi bi-person-gear text-terracotta"></i> Account Settings</a>
        </div>
      </div>

      <!-- Main Dashboard Content -->
      <div class="col-12 col-lg-9 col-xl-10">
        
        <!-- Welcome Banner -->
        <div class="dashboard-banner d-flex align-items-center justify-content-between flex-wrap gap-4">
          <div>
            <h1 class="fw-extrabold display-5 mb-2">Ready for your next getaway?</h1>
            <p class="fs-5 opacity-75 mb-0">Discover the best seasonal stays and trending hotels across the Philippines.</p>
          </div>
          <a href="home.php" class="btn btn-light btn-lg rounded-pill fw-bold text-terracotta shadow px-4 py-3">
            <i class="bi bi-map-fill me-2"></i>Open Interactive Map
          </a>
        </div>

        <!-- Trending Section -->
        <h3 class="section-title"><i class="bi bi-fire text-danger"></i> Top Trending Hotels (2026)</h3>
        <div class="row g-4 mb-5">
          <?php foreach ($trendingHotels as $hotel): ?>
            <div class="col-12 col-md-6 col-xl-4">
              <div class="trend-card">
                <img src="<?= htmlspecialchars($hotel['image']) ?>" alt="<?= htmlspecialchars($hotel['title']) ?>">
                <div class="p-3">
                  <div class="d-flex justify-content-between align-items-start mb-2 flex-wrap gap-1">
                    <h5 class="fw-bold text-mocha mb-0"><?= htmlspecialchars($hotel['title']) ?></h5>
                    <span class="badge bg-sage rounded-pill">₱<?= number_format($hotel['price_from']) ?></span>
                  </div>
                  <p class="text-secondary small mb-3"><i class="bi bi-geo-alt-fill text-terracotta me-1"></i><?= htmlspecialchars($hotel['city']) ?></p>
                  <div class="d-flex gap-2">
                    <a href="home.php?locate=<?= urlencode($hotel['id']) ?>" class="btn btn-outline-primary flex-fill fw-bold rounded-pill">View Availability</a>
                    <a href="home.php?tour=<?= urlencode($hotel['id']) ?>" class="btn btn-outline-info rounded-pill px-3 fw-bold" title="Open 360° Virtual Tour"><i class="bi bi-vr me-1"></i>360°</a>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Seasonal Recommendations -->
        <h3 class="section-title"><i class="bi bi-sun-fill text-amber"></i> Seasonal Recommendations</h3>
        <div class="row g-4 mb-5">
          <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100" style="background: var(--bg-card);">
              <div class="row g-0 h-100">
                <div class="col-12 col-sm-4">
                  <img src="https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=600&q=80" class="img-fluid h-100 object-fit-cover" alt="Summer Resort" style="min-height: 180px;">
                </div>
                <div class="col-12 col-sm-8">
                  <div class="card-body">
                    <span class="badge bg-warning text-dark mb-2 rounded-pill"><i class="bi bi-brightness-high-fill me-1"></i> Summer 2026</span>
                    <h5 class="card-title fw-bold text-mocha">Ultimate Beach Escapes</h5>
                    <p class="card-text small text-muted">Discover top-rated resorts with private beaches in Cebu and Palawan.</p>
                    <a href="home.php?category=resort" class="btn btn-sm btn-primary rounded-pill px-3">Explore Resorts</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100" style="background: var(--bg-card);">
              <div class="row g-0 h-100">
                <div class="col-12 col-sm-4">
                  <img src="https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=600&q=80" class="img-fluid h-100 object-fit-cover" alt="Heritage Events" style="min-height: 180px;">
                </div>
                <div class="col-12 col-sm-8">
                  <div class="card-body">
                    <span class="badge bg-danger mb-2 rounded-pill"><i class="bi bi-calendar-event-fill me-1"></i> Upcoming Festival</span>
                    <h5 class="card-title fw-bold text-mocha">Cultural Heritage Tour</h5>
                    <p class="card-text small text-muted">Stay in historic landmarks during the upcoming national cultural events.</p>
                    <a href="home.php?category=heritage" class="btn btn-sm btn-primary rounded-pill px-3">View Heritage Stays</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

</body>
</html>
