<?php
// Forward to root recent_bookings.php for correct assets and routing
require __DIR__ . '/../recent_bookings.php';
