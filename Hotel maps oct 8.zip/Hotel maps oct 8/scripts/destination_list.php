<?php
// Forward to root destination_list.php for correct assets and routing
require __DIR__ . '/../destination_list.php';
